"use client";

import { useState, useEffect, useRef } from "react";

// ════════════════════════════════════════════════════════════════
//  ── EDIT YOUR DETAILS HERE — everything else updates automatically
// ════════════════════════════════════════════════════════════════
const ME = {
  name:       "Ranjith Kumar S",
  email:      "your.email@gmail.com",          // ← replace
  phone:      null,                             // ← e.g. "+91 98765 43210" or null to hide
  location:   "Bhavani, Tamil Nadu, India",
  github:     "https://github.com/your-username",   // ← replace
  linkedin:   "https://www.linkedin.com/in/ranjith-kumar-s-019a29291",
  resumeUrl:  "#",                              // ← replace with your resume PDF link
  chatbotUrl: "#",                              // ← replace with Chatbase demo URL
  ieeeUrl:    "#",                              // ← replace with IEEE paper URL if available
  faceRecogGithub: "#",                         // ← replace with repo URL
};
// ════════════════════════════════════════════════════════════════

const ROLES = ["Salesforce Developer", "Python Engineer", "AI/ML Engineer"];

const SKILLS = [
  { category: "Salesforce",    items: ["Apex", "LWC", "SOQL", "Flows", "Sales Cloud", "REST APIs"] },
  { category: "Python & ML",   items: ["Python", "TensorFlow", "OpenCV", "NumPy", "Pandas", "Scikit-learn"] },
  { category: "AI & GenAI",    items: ["ChatGPT", "Generative AI", "Prompt Engineering", "Vision Transformers", "CNN", "Deep Learning"] },
  { category: "Tools & Infra", items: ["Git", "GitHub", "SQL", "VS Code", "Jupyter", "Salesforce CLI"] },
];

const EXPERIENCES = [
  {
    role: "Salesforce Developer Intern",
    company: "SmartInternz + AICTE",
    period: "2024",
    desc: "Developed Salesforce applications using Apex, Lightning Web Components (LWC), and Flows under the AICTE-backed SmartInternz virtual internship program. Worked on real-world CRM use cases, automation, and data modeling with SOQL.",
    tags: ["Apex", "LWC", "SOQL", "Flows"],
    icon: "☁️",
  },
  {
    role: "Python Developer Intern",
    company: "Myura Software Solutions",
    period: "2023",
    desc: "Built Python-based automation scripts and backend utilities. Worked on data processing pipelines and contributed to internal tooling projects using core Python libraries and REST API integrations.",
    tags: ["Python", "REST APIs", "Automation"],
    icon: "🐍",
  },
  {
    role: "Python Intern",
    company: "REJOLA",
    period: "2023",
    desc: "Assisted in developing Python applications for data handling and processing tasks. Gained hands-on experience with file I/O, data structures, and building small-scale utilities in a professional environment.",
    tags: ["Python", "Data Processing"],
    icon: "💻",
  },
];

const CERTIFICATIONS = [
  { title: "IBM Data Science 101",         issuer: "IBM / Coursera",       icon: "🏅", color: "#4F46E5" },
  { title: "Salesforce Developer Intern",  issuer: "SmartInternz + AICTE", icon: "☁️", color: "#06B6D4" },
  { title: "AI for Everyone",              issuer: "Wadhwani Foundation",   icon: "🧠", color: "#7C3AED" },
  { title: "Freedom with AI",              issuer: "Freedom with AI",       icon: "⚡", color: "#10B981" },
  { title: "AI Tools & ChatGPT",           issuer: "be10x",                 icon: "🤖", color: "#F59E0B" },
];

const SOFT_SKILLS = ["Problem Solving", "Team Collaboration", "Adaptability", "Communication", "Time Management", "Continuous Learning"];

const INTERESTS = [
  { label: "Computer Vision",     icon: "👁️" },
  { label: "Generative AI",       icon: "✨" },
  { label: "Salesforce Ecosystem",icon: "☁️" },
  { label: "Deep Learning",       icon: "🧬" },
  { label: "Content Creation",    icon: "🎬" },
  { label: "Open Source",         icon: "🌐" },
];

// ── Hooks ───────────────────────────────────────────────────────
function useInView(threshold = 0.12) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, inView];
}

function useTyping(words, speed = 80, pause = 1800) {
  const [display, setDisplay] = useState("");
  const [wi, setWi] = useState(0);
  const [ci, setCi] = useState(0);
  const [del, setDel] = useState(false);
  useEffect(() => {
    const w = words[wi];
    let t;
    if (!del && ci < w.length)   t = setTimeout(() => setCi(c => c + 1), speed);
    else if (!del)                t = setTimeout(() => setDel(true), pause);
    else if (del && ci > 0)      t = setTimeout(() => setCi(c => c - 1), speed / 2);
    else { setDel(false); setWi(i => (i + 1) % words.length); }
    setDisplay(w.slice(0, ci));
    return () => clearTimeout(t);
  }, [ci, del, wi, words, speed, pause]);
  return display;
}

// ── Primitives ──────────────────────────────────────────────────
function GridBg() {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
      background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(79,70,229,0.18) 0%, transparent 70%), radial-gradient(ellipse 50% 40% at 80% 80%, rgba(124,58,237,0.10) 0%, transparent 60%)" }}>
      <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="48" height="48" patternUnits="userSpaceOnUse">
            <path d="M 48 0 L 0 0 0 48" fill="none" stroke="rgba(99,102,241,0.07)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
    </div>
  );
}

function Section({ id, children, tinted = false }) {
  const [ref, inView] = useInView();
  return (
    <section id={id} ref={ref} style={{
      padding: "5rem 1.5rem",
      background: tinted ? "rgba(26,26,46,0.35)" : "transparent",
      opacity: inView ? 1 : 0,
      transform: inView ? "translateY(0)" : "translateY(28px)",
      transition: "opacity 0.6s ease, transform 0.6s ease",
      position: "relative", zIndex: 1,
    }}>
      <div style={{ maxWidth: "960px", margin: "0 auto" }}>{children}</div>
    </section>
  );
}

function Label({ text }) {
  return <p style={{ fontFamily: "'Inter',sans-serif", fontSize: "0.7rem", fontWeight: 700,
    color: "#6366F1", letterSpacing: "0.18em", textTransform: "uppercase", marginBottom: "0.4rem" }}>{text}</p>;
}

function Title({ children }) {
  return <h2 style={{ fontFamily: "'Space Grotesk',sans-serif", fontSize: "clamp(1.8rem,4vw,2.6rem)",
    fontWeight: 800, color: "#F8FAFC", marginBottom: "2rem", lineHeight: 1.1, letterSpacing: "-0.03em" }}>{children}</h2>;
}

function Card({ children, style = {} }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ background: "rgba(26,26,46,0.6)", backdropFilter: "blur(12px)",
        border: `1px solid ${hov ? "rgba(99,102,241,0.45)" : "rgba(99,102,241,0.13)"}`,
        borderRadius: "14px", padding: "1.5rem",
        transition: "border-color 0.25s, transform 0.25s, box-shadow 0.25s",
        transform: hov ? "translateY(-3px)" : "none",
        boxShadow: hov ? "0 8px 32px rgba(79,70,229,0.14)" : "none", ...style }}>
      {children}
    </div>
  );
}

function Tag({ label, color = "#4F46E5" }) {
  return <span style={{ display: "inline-block", padding: "0.22rem 0.6rem", borderRadius: "999px",
    fontSize: "0.7rem", fontWeight: 600, fontFamily: "'Inter',sans-serif",
    background: `${color}20`, color, border: `1px solid ${color}40`, margin: "0.2rem" }}>{label}</span>;
}

function Btn({ href, children, variant = "primary" }) {
  const [hov, setHov] = useState(false);
  const styles = {
    primary: { bg: hov ? "rgba(99,102,241,0.2)" : "rgba(99,102,241,0.1)", color: "#A5B4FC", border: "1px solid rgba(99,102,241,0.35)" },
    cyan:    { bg: hov ? "rgba(6,182,212,0.2)"  : "rgba(6,182,212,0.1)",  color: "#67E8F9", border: "1px solid rgba(6,182,212,0.35)" },
  };
  const s = styles[variant];
  return (
    <a href={href} target="_blank" rel="noopener noreferrer"
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "inline-flex", alignItems: "center", gap: "0.4rem",
        padding: "0.45rem 1rem", borderRadius: "7px", fontSize: "0.8rem",
        fontFamily: "'Inter',sans-serif", fontWeight: 600, textDecoration: "none",
        background: s.bg, color: s.color, border: s.border, transition: "all 0.2s" }}>
      {children}
    </a>
  );
}

// ── Navbar ──────────────────────────────────────────────────────
function Navbar() {
  const [open, setOpen] = useState(false);
  const links = ["About","Skills","Experience","Projects","Research","Certifications","Contact"];
  return (
    <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: "rgba(10,10,15,0.88)", backdropFilter: "blur(16px)",
      borderBottom: "1px solid rgba(99,102,241,0.14)",
      padding: "0 2rem", display: "flex", alignItems: "center", justifyContent: "space-between", height: "60px" }}>
      <span style={{ fontFamily: "'Space Grotesk',sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#fff" }}>
        <span style={{ color: "#6366F1" }}>RK</span>.dev
      </span>
      <div className="nav-desktop" style={{ display: "flex", gap: "1.6rem" }}>
        {links.map(l => (
          <a key={l} href={`#${l.toLowerCase()}`}
            style={{ fontFamily: "'Inter',sans-serif", fontSize: "0.82rem", fontWeight: 500,
              color: "rgba(248,250,252,0.65)", textDecoration: "none", transition: "color 0.2s" }}
            onMouseEnter={e => e.target.style.color="#A5B4FC"}
            onMouseLeave={e => e.target.style.color="rgba(248,250,252,0.65)"}>{l}</a>
        ))}
      </div>
      <button className="nav-mobile" onClick={() => setOpen(o=>!o)}
        style={{ display: "none", background: "none", border: "none", color: "#fff", fontSize: "1.4rem", cursor: "pointer" }}
        aria-label="Toggle menu">☰</button>
      {open && (
        <div style={{ position: "fixed", top: "60px", left: 0, right: 0, zIndex: 99,
          background: "rgba(10,10,15,0.97)", backdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(99,102,241,0.14)", padding: "1rem 2rem 1.5rem",
          display: "flex", flexDirection: "column", gap: "1rem" }}>
          {links.map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} onClick={() => setOpen(false)}
              style={{ fontFamily: "'Inter',sans-serif", fontSize: "1rem", fontWeight: 500,
                color: "rgba(248,250,252,0.8)", textDecoration: "none" }}>{l}</a>
          ))}
        </div>
      )}
    </nav>
  );
}

// ── Hero ────────────────────────────────────────────────────────
function Hero() {
  const typed = useTyping(ROLES);
  const heroBtn = (href, label, variant) => {
    const styles = {
      grad:    { background: "linear-gradient(135deg,#4F46E5,#7C3AED)", color: "#fff", border: "none", boxShadow: "0 4px 20px rgba(79,70,229,0.35)" },
      outline: { background: "rgba(99,102,241,0.1)", color: "#A5B4FC", border: "1px solid rgba(99,102,241,0.35)" },
      cyan:    { background: "rgba(6,182,212,0.1)",  color: "#67E8F9", border: "1px solid rgba(6,182,212,0.35)" },
    };
    return (
      <a href={href} style={{ display:"inline-flex", alignItems:"center", gap:"0.45rem",
        padding:"0.72rem 1.5rem", borderRadius:"8px",
        fontFamily:"'Inter',sans-serif", fontWeight:600, fontSize:"0.88rem",
        textDecoration:"none", transition:"all 0.2s", ...styles[variant] }}
        onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.opacity="0.9"; }}
        onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.opacity="1"; }}>
        {label}
      </a>
    );
  };

  return (
    <section id="hero" style={{ minHeight: "100vh", display: "flex", alignItems: "center",
      padding: "7rem 1.5rem 4rem", position: "relative" }}>
      <div style={{ maxWidth: "860px", width: "100%", position: "relative", zIndex: 1 }}>

        {/* Open-to badge */}
        <div style={{ display:"inline-flex", alignItems:"center", gap:"0.5rem",
          background:"rgba(99,102,241,0.1)", border:"1px solid rgba(99,102,241,0.28)",
          borderRadius:"999px", padding:"0.32rem 0.9rem", marginBottom:"1.6rem",
          fontFamily:"'Inter',sans-serif", fontSize:"0.75rem", color:"#A5B4FC", fontWeight:500 }}>
          <span style={{ width:"6px", height:"6px", borderRadius:"50%", background:"#4ADE80",
            display:"inline-block", boxShadow:"0 0 8px #4ADE80" }} />
          Open to Opportunities
        </div>

        <h1 style={{ fontFamily:"'Space Grotesk',sans-serif",
          fontSize:"clamp(2.4rem,7vw,4.8rem)", fontWeight:800, lineHeight:1.05,
          color:"#F8FAFC", margin:"0 0 0.5rem", letterSpacing:"-0.03em" }}>
          {ME.name}
        </h1>

        <div style={{ fontFamily:"'Space Grotesk',sans-serif",
          fontSize:"clamp(1.15rem,3vw,1.65rem)", fontWeight:600, color:"#818CF8",
          marginBottom:"1.1rem", minHeight:"2.1rem", letterSpacing:"-0.01em" }}>
          {typed}<span style={{ animation:"blink 1s step-end infinite" }}>|</span>
        </div>

        <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"clamp(0.95rem,2vw,1.15rem)",
          color:"rgba(248,250,252,0.6)", lineHeight:1.7, maxWidth:"580px", marginBottom:"2.5rem" }}>
          Building AI-powered solutions and Salesforce applications — from intelligent face recognition systems to enterprise CRM automation.
        </p>

        <div style={{ display:"flex", gap:"0.85rem", flexWrap:"wrap" }}>
          {heroBtn(ME.resumeUrl,   "⬇ Download Resume", "grad")}
          {heroBtn("#projects",    "🚀 View Projects",   "outline")}
          {heroBtn("#contact",     "✉ Contact Me",       "cyan")}
        </div>

        {/* Stats row */}
        <div style={{ display:"flex", gap:"2.5rem", marginTop:"3.2rem", flexWrap:"wrap" }}>
          {[["3+","Internships"],["1","IEEE Publication"],["5+","Certifications"],["2","Major Projects"]].map(([n,l]) => (
            <div key={l}>
              <div style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1.55rem",
                fontWeight:800, color:"#818CF8" }}>{n}</div>
              <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.75rem",
                color:"rgba(248,250,252,0.4)", marginTop:"0.1rem" }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Orb */}
      <div className="hero-orb" style={{ position:"absolute", right:"5%", top:"50%",
        transform:"translateY(-50%)", width:"340px", height:"340px", borderRadius:"50%",
        background:"radial-gradient(circle,rgba(124,58,237,0.16) 0%,rgba(79,70,229,0.07) 50%,transparent 70%)",
        filter:"blur(2px)", pointerEvents:"none", zIndex:0 }} />
    </section>
  );
}

// ── About ───────────────────────────────────────────────────────
function About() {
  return (
    <Section id="about" tinted>
      <Label text="Who I Am" /><Title>About Me</Title>
      <div className="about-grid" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"1.25rem" }}>
        <div style={{ gridColumn:"1 / -1" }}>
          <Card>
            <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"1.02rem",
              color:"rgba(248,250,252,0.75)", lineHeight:1.8, margin:0 }}>
              I'm <strong style={{color:"#A5B4FC"}}>Ranjith Kumar S</strong>, a B.Tech Information Technology graduate (2021–2025) from KSR Institute for Engineering & Technology, Tamil Nadu. I build at the intersection of{" "}
              <strong style={{color:"#67E8F9"}}>Salesforce development</strong>,{" "}
              <strong style={{color:"#A5B4FC"}}>Python engineering</strong>, and{" "}
              <strong style={{color:"#C4B5FD"}}>AI/ML research</strong>.
              <br /><br />
              My work spans enterprise CRM automation using Apex and LWC to peer-reviewed deep learning research — my CNN + Vision Transformer face recognition paper was published at{" "}
              <strong style={{color:"#FBBF24"}}>IEEE IConIC 2025</strong>. I'm passionate about building intelligent systems that solve real-world problems.
            </p>
          </Card>
        </div>
        {[
          { icon:"☁️", title:"Salesforce Development", desc:"Apex triggers, LWC components, declarative Flows, SOQL data modeling, and Sales Cloud customization." },
          { icon:"🐍", title:"Python & Backend",        desc:"Automation scripts, data pipelines, REST API integrations, and backend utilities across multiple production internships." },
          { icon:"🧠", title:"AI/ML & Deep Learning",   desc:"CNN architectures, Vision Transformers, OpenCV image processing, TensorFlow model training, and computer vision systems." },
          { icon:"✨", title:"Generative AI",            desc:"Prompt engineering, ChatGPT-powered tools, and AI chatbots built on platforms like Chatbase for real-world applications." },
        ].map(item => (
          <Card key={item.title}>
            <div style={{ fontSize:"1.7rem", marginBottom:"0.65rem" }}>{item.icon}</div>
            <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"0.95rem",
              fontWeight:700, color:"#F8FAFC", marginBottom:"0.45rem" }}>{item.title}</h3>
            <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.83rem",
              color:"rgba(248,250,252,0.55)", lineHeight:1.65, margin:0 }}>{item.desc}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
}

// ── Skills ──────────────────────────────────────────────────────
function SkillBadge({ label }) {
  const [hov, setHov] = useState(false);
  return (
    <span onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ display:"inline-flex", alignItems:"center", padding:"0.42rem 0.85rem", borderRadius:"8px",
        fontFamily:"'Inter',sans-serif", fontSize:"0.8rem", fontWeight:600, cursor:"default",
        background: hov?"rgba(99,102,241,0.22)":"rgba(99,102,241,0.08)",
        color: hov?"#C7D2FE":"#A5B4FC",
        border:`1px solid ${hov?"rgba(99,102,241,0.5)":"rgba(99,102,241,0.2)"}`,
        transition:"all 0.2s", transform:hov?"translateY(-1px)":"none", margin:"0.25rem" }}>
      {label}
    </span>
  );
}

function Skills() {
  return (
    <Section id="skills">
      <Label text="Toolkit" /><Title>Skills & Technologies</Title>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:"1.1rem" }}>
        {SKILLS.map(cat => (
          <Card key={cat.category}>
            <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"0.78rem", fontWeight:700,
              color:"#6366F1", letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:"0.9rem" }}>
              {cat.category}
            </h3>
            <div style={{ display:"flex", flexWrap:"wrap" }}>
              {cat.items.map(s => <SkillBadge key={s} label={s} />)}
            </div>
          </Card>
        ))}
      </div>
    </Section>
  );
}

// ── Experience ──────────────────────────────────────────────────
function Experience() {
  return (
    <Section id="experience" tinted>
      <Label text="Career Path" /><Title>Experience</Title>
      <div style={{ position:"relative", paddingLeft:"2rem" }}>
        <div style={{ position:"absolute", left:"0.7rem", top:0, bottom:0, width:"2px",
          background:"linear-gradient(to bottom,#4F46E5,#7C3AED,rgba(124,58,237,0))" }} />
        <div style={{ display:"flex", flexDirection:"column", gap:"1.4rem" }}>
          {EXPERIENCES.map((exp, i) => (
            <div key={i} style={{ position:"relative" }}>
              <div style={{ position:"absolute", left:"-2rem", top:"1.5rem",
                width:"13px", height:"13px", borderRadius:"50%",
                background:"linear-gradient(135deg,#4F46E5,#7C3AED)",
                boxShadow:"0 0 10px rgba(99,102,241,0.6)", border:"2px solid #0A0A0F" }} />
              <Card>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", flexWrap:"wrap", gap:"0.5rem", marginBottom:"0.6rem" }}>
                  <div>
                    <div style={{ display:"flex", alignItems:"center", gap:"0.55rem", marginBottom:"0.25rem" }}>
                      <span style={{ fontSize:"1.1rem" }}>{exp.icon}</span>
                      <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1rem",
                        fontWeight:700, color:"#F8FAFC", margin:0 }}>{exp.role}</h3>
                    </div>
                    <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.82rem",
                      color:"#818CF8", fontWeight:600 }}>{exp.company}</div>
                  </div>
                  <span style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.72rem", fontWeight:600,
                    color:"#67E8F9", background:"rgba(6,182,212,0.1)", border:"1px solid rgba(6,182,212,0.3)",
                    padding:"0.18rem 0.65rem", borderRadius:"999px", whiteSpace:"nowrap" }}>{exp.period}</span>
                </div>
                <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.83rem",
                  color:"rgba(248,250,252,0.6)", lineHeight:1.65, marginBottom:"0.8rem" }}>{exp.desc}</p>
                <div>{exp.tags.map(t => <Tag key={t} label={t} />)}</div>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ── Projects ────────────────────────────────────────────────────
function Projects() {
  return (
    <Section id="projects">
      <Label text="What I've Built" /><Title>Projects</Title>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))", gap:"1.4rem" }}>

        {/* IEEE project */}
        <Card style={{ borderColor:"rgba(245,158,11,0.28)", background:"rgba(26,26,46,0.75)" }}>
          <div style={{ display:"inline-block", padding:"0.22rem 0.65rem", borderRadius:"999px",
            background:"rgba(245,158,11,0.15)", border:"1px solid rgba(245,158,11,0.38)",
            fontFamily:"'Inter',sans-serif", fontSize:"0.7rem", fontWeight:700, color:"#FBBF24",
            marginBottom:"0.85rem" }}>📄 IEEE Published</div>
          <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1.05rem", fontWeight:800,
            color:"#F8FAFC", marginBottom:"0.28rem", lineHeight:1.25 }}>
            Face Recognition using CNN + Vision Transformer
          </h3>
          <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.76rem",
            color:"#818CF8", marginBottom:"0.7rem", fontWeight:500 }}>IEEE IConIC 2025 Published Research</div>
          <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.83rem",
            color:"rgba(248,250,252,0.6)", lineHeight:1.65, marginBottom:"0.95rem" }}>
            A hybrid deep learning architecture combining CNN's local feature extraction with Vision Transformers' global attention for highly accurate face recognition.
          </p>
          <div style={{ marginBottom:"1.1rem" }}>
            {["Python","TensorFlow","OpenCV","CNN","Vision Transformer","Deep Learning"].map(t => <Tag key={t} label={t} color="#F59E0B" />)}
          </div>
          <div style={{ display:"flex", gap:"0.6rem", flexWrap:"wrap" }}>
            <Btn href={ME.faceRecogGithub}>⟨/⟩ GitHub</Btn>
            <Btn href={ME.ieeeUrl} variant="cyan">📄 IEEE Paper</Btn>
          </div>
        </Card>

        {/* Chatbot project */}
        <Card>
          <div style={{ display:"inline-block", padding:"0.22rem 0.65rem", borderRadius:"999px",
            background:"rgba(6,182,212,0.12)", border:"1px solid rgba(6,182,212,0.35)",
            fontFamily:"'Inter',sans-serif", fontSize:"0.7rem", fontWeight:700, color:"#67E8F9",
            marginBottom:"0.85rem" }}>🤖 Live Demo</div>
          <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1.05rem", fontWeight:800,
            color:"#F8FAFC", marginBottom:"0.28rem", lineHeight:1.25 }}>
            AI Resume Explainer Chatbot
          </h3>
          <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.76rem",
            color:"#818CF8", marginBottom:"0.7rem", fontWeight:500 }}>Conversational AI Portfolio Tool</div>
          <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.83rem",
            color:"rgba(248,250,252,0.6)", lineHeight:1.65, marginBottom:"0.95rem" }}>
            An AI-powered chatbot built with Chatbase that lets recruiters interactively explore my skills, projects, and experience in a conversational format.
          </p>
          <div style={{ marginBottom:"1.1rem" }}>
            {["ChatGPT","Chatbase","Prompt Engineering","GenAI"].map(t => <Tag key={t} label={t} color="#7C3AED" />)}
          </div>
          <div style={{ display:"flex", gap:"0.6rem", flexWrap:"wrap" }}>
            <Btn href={ME.chatbotUrl} variant="cyan">↗ Try Chatbot</Btn>
          </div>
        </Card>
      </div>
    </Section>
  );
}

// ── Research ────────────────────────────────────────────────────
function Research() {
  return (
    <Section id="research" tinted>
      <Label text="Academic Work" /><Title>Research & Publications</Title>
      <Card style={{ borderColor:"rgba(245,158,11,0.22)", background:"rgba(26,26,46,0.8)" }}>
        <div style={{ display:"flex", gap:"1.1rem", alignItems:"flex-start", flexWrap:"wrap" }}>
          <div style={{ minWidth:"50px", height:"50px", borderRadius:"12px", flexShrink:0,
            background:"linear-gradient(135deg,rgba(245,158,11,0.18),rgba(251,191,36,0.08))",
            border:"1px solid rgba(245,158,11,0.28)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.4rem" }}>📄</div>
          <div style={{ flex:1 }}>
            <div style={{ display:"inline-block", padding:"0.2rem 0.6rem", borderRadius:"999px",
              background:"rgba(245,158,11,0.14)", border:"1px solid rgba(245,158,11,0.32)",
              fontFamily:"'Inter',sans-serif", fontSize:"0.68rem", fontWeight:700, color:"#FBBF24",
              marginBottom:"0.7rem" }}>IEEE IConIC 2025</div>
            <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1.15rem", fontWeight:800,
              color:"#F8FAFC", marginBottom:"0.45rem", lineHeight:1.25 }}>
              Face Recognition using CNN and Vision Transformers
            </h3>
            <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.83rem",
              color:"rgba(248,250,252,0.6)", lineHeight:1.7, marginBottom:"0.9rem" }}>
              A peer-reviewed paper presenting a novel hybrid architecture that fuses CNN's spatial feature extraction with Vision Transformers' long-range dependency modeling. Evaluated on standard face recognition benchmarks, demonstrating improved accuracy and robustness compared to standalone approaches.
            </p>
            <div style={{ marginBottom:"0.9rem" }}>
              {["CNN","Vision Transformer","TensorFlow","OpenCV","Deep Learning","Computer Vision"].map(t => <Tag key={t} label={t} color="#F59E0B" />)}
            </div>
            <div style={{ display:"flex", gap:"0.75rem", flexWrap:"wrap" }}>
              <Btn href={ME.ieeeUrl} variant="cyan">📖 View on IEEE Xplore</Btn>
            </div>
          </div>
        </div>
      </Card>
    </Section>
  );
}

// ── Certifications ──────────────────────────────────────────────
function Certifications() {
  return (
    <Section id="certifications">
      <Label text="Credentials" /><Title>Certifications</Title>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(190px,1fr))", gap:"1rem" }}>
        {CERTIFICATIONS.map(c => (
          <Card key={c.title}>
            <div style={{ width:"40px", height:"40px", borderRadius:"10px", flexShrink:0,
              background:`${c.color}14`, border:`1px solid ${c.color}2e`,
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:"1.2rem", marginBottom:"0.85rem" }}>{c.icon}</div>
            <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"0.88rem",
              fontWeight:700, color:"#F8FAFC", marginBottom:"0.28rem", lineHeight:1.3 }}>{c.title}</h3>
            <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.73rem",
              color:"rgba(248,250,252,0.42)", margin:0 }}>{c.issuer}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
}

// ── Education ───────────────────────────────────────────────────
function Education() {
  return (
    <Section id="education" tinted>
      <Label text="Academic Background" /><Title>Education</Title>
      <Card style={{ borderColor:"rgba(99,102,241,0.22)" }}>
        <div style={{ display:"flex", gap:"1.1rem", alignItems:"flex-start", flexWrap:"wrap" }}>
          <div style={{ width:"50px", height:"50px", borderRadius:"12px", flexShrink:0,
            background:"linear-gradient(135deg,rgba(79,70,229,0.22),rgba(124,58,237,0.12))",
            border:"1px solid rgba(99,102,241,0.28)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.4rem" }}>🎓</div>
          <div>
            <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"1.1rem",
              fontWeight:800, color:"#F8FAFC", marginBottom:"0.22rem" }}>
              Bachelor of Technology — Information Technology
            </h3>
            <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.88rem",
              color:"#818CF8", fontWeight:600, marginBottom:"0.35rem" }}>
              KSR Institute for Engineering & Technology, Tamil Nadu
            </div>
            <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.78rem",
              color:"rgba(248,250,252,0.42)" }}>2021 – 2025</div>
          </div>
        </div>
      </Card>
    </Section>
  );
}

// ── Soft Skills + Interests ─────────────────────────────────────
function More() {
  return (
    <Section id="more">
      <div className="two-col" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"3rem" }}>
        <div>
          <Label text="Attributes" />
          <Title>Soft Skills</Title>
          <div style={{ display:"flex", flexWrap:"wrap", gap:"0.5rem" }}>
            {SOFT_SKILLS.map(s => (
              <span key={s} style={{ display:"inline-block", padding:"0.42rem 0.9rem", borderRadius:"8px",
                fontFamily:"'Inter',sans-serif", fontSize:"0.8rem", fontWeight:600,
                background:"rgba(16,185,129,0.08)", color:"#6EE7B7",
                border:"1px solid rgba(16,185,129,0.2)" }}>{s}</span>
            ))}
          </div>
        </div>
        <div>
          <Label text="Passion Areas" />
          <Title>Interests</Title>
          <div style={{ display:"flex", flexWrap:"wrap", gap:"0.5rem" }}>
            {INTERESTS.map(i => (
              <span key={i.label} style={{ display:"inline-flex", alignItems:"center", gap:"0.38rem",
                padding:"0.42rem 0.9rem", borderRadius:"8px",
                fontFamily:"'Inter',sans-serif", fontSize:"0.8rem", fontWeight:600,
                background:"rgba(124,58,237,0.1)", color:"#C4B5FD",
                border:"1px solid rgba(124,58,237,0.2)" }}>
                <span>{i.icon}</span>{i.label}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
}

// ── Contact ─────────────────────────────────────────────────────
function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name:"", email:"", message:"" });

  const inp = {
    width:"100%", padding:"0.72rem 1rem", borderRadius:"8px",
    background:"rgba(26,26,46,0.7)", border:"1px solid rgba(99,102,241,0.2)",
    color:"#F8FAFC", fontFamily:"'Inter',sans-serif", fontSize:"0.88rem",
    outline:"none", boxSizing:"border-box", transition:"border-color 0.2s",
  };

  const contactItems = [
    { icon:"✉️", label:"Email",    value: ME.email,    href: `mailto:${ME.email}` },
    ...(ME.phone ? [{ icon:"📱", label:"Phone", value: ME.phone, href: `tel:${ME.phone}` }] : []),
    { icon:"📍", label:"Location", value: ME.location, href: null },
    { icon:"🔗", label:"LinkedIn", value: "linkedin.com/in/ranjith-kumar-s-019a29291", href: ME.linkedin },
    { icon:"⟨/⟩",label:"GitHub",  value: "github.com/your-username",     href: ME.github },
  ];

  return (
    <Section id="contact" tinted>
      <Label text="Get In Touch" /><Title>Contact</Title>
      <div className="contact-grid" style={{ display:"grid", gridTemplateColumns:"1fr 1.4fr", gap:"1.8rem" }}>
        <div style={{ display:"flex", flexDirection:"column", gap:"0.85rem" }}>
          {contactItems.map(c => (
            <Card key={c.label} style={{ padding:"0.88rem 1.1rem" }}>
              <div style={{ display:"flex", alignItems:"center", gap:"0.75rem" }}>
                <span style={{ fontSize:"1rem" }}>{c.icon}</span>
                <div>
                  <div style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.68rem",
                    color:"rgba(248,250,252,0.38)", marginBottom:"0.08rem" }}>{c.label}</div>
                  {c.href
                    ? <a href={c.href} target="_blank" rel="noopener noreferrer"
                        style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.82rem",
                          color:"#A5B4FC", fontWeight:500, textDecoration:"none" }}>{c.value}</a>
                    : <span style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.82rem",
                        color:"#A5B4FC", fontWeight:500 }}>{c.value}</span>
                  }
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Card>
          {sent ? (
            <div style={{ textAlign:"center", padding:"2rem 0" }}>
              <div style={{ fontSize:"2.2rem", marginBottom:"0.8rem" }}>✅</div>
              <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", color:"#F8FAFC", marginBottom:"0.4rem" }}>Message Sent!</h3>
              <p style={{ fontFamily:"'Inter',sans-serif", color:"rgba(248,250,252,0.55)", fontSize:"0.88rem" }}>
                Thanks for reaching out. I'll get back to you soon.
              </p>
            </div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:"0.9rem" }}>
              <h3 style={{ fontFamily:"'Space Grotesk',sans-serif", fontSize:"0.95rem",
                fontWeight:700, color:"#F8FAFC" }}>Send a Message</h3>
              {[
                { key:"name",    type:"text",  ph:"Your Name" },
                { key:"email",   type:"email", ph:"Email Address" },
              ].map(f => (
                <input key={f.key} type={f.type} placeholder={f.ph} value={form[f.key]}
                  onChange={e => setForm(p => ({...p, [f.key]:e.target.value}))}
                  style={inp}
                  onFocus={e => e.target.style.borderColor="rgba(99,102,241,0.5)"}
                  onBlur={e  => e.target.style.borderColor="rgba(99,102,241,0.2)"}
                />
              ))}
              <textarea placeholder="Your Message" rows={4} value={form.message}
                onChange={e => setForm(p => ({...p, message:e.target.value}))}
                style={{...inp, resize:"vertical"}}
                onFocus={e => e.target.style.borderColor="rgba(99,102,241,0.5)"}
                onBlur={e  => e.target.style.borderColor="rgba(99,102,241,0.2)"}
              />
              <button onClick={() => { if(form.name&&form.email&&form.message) setSent(true); }}
                style={{ padding:"0.78rem", borderRadius:"8px", border:"none", cursor:"pointer",
                  background:"linear-gradient(135deg,#4F46E5,#7C3AED)", color:"#fff",
                  fontFamily:"'Space Grotesk',sans-serif", fontSize:"0.88rem", fontWeight:700,
                  transition:"opacity 0.2s,transform 0.2s", boxShadow:"0 4px 18px rgba(79,70,229,0.32)" }}
                onMouseEnter={e=>{e.target.style.opacity="0.88";e.target.style.transform="translateY(-1px)";}}
                onMouseLeave={e=>{e.target.style.opacity="1";e.target.style.transform="none";}}>
                Send Message →
              </button>
            </div>
          )}
        </Card>
      </div>
    </Section>
  );
}

// ── Footer ──────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ padding:"2rem", textAlign:"center", position:"relative", zIndex:1,
      borderTop:"1px solid rgba(99,102,241,0.1)" }}>
      <p style={{ fontFamily:"'Inter',sans-serif", fontSize:"0.78rem",
        color:"rgba(248,250,252,0.28)", margin:0 }}>
        © 2025 {ME.name} · Built with ❤️ and lots of ☕
      </p>
    </footer>
  );
}

// ── App ─────────────────────────────────────────────────────────
export default function PortfolioBody() {
  return (
    <>
      <GridBg />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Projects />
        <Research />
        <Certifications />
        <Education />
        <More />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
